// Este componente não é mais necessário.
// O fluxo de pagamento foi atualizado para redirecionar o usuário
// diretamente para a página de checkout segura do Stripe, em vez de
// usar um formulário de pagamento intermediário.
// Este arquivo pode ser removido com segurança do projeto.
